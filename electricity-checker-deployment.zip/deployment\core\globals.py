from aiogram import Bot
from config.settings import TOKEN

# Global bot instance
bot = Bot(token=TOKEN)