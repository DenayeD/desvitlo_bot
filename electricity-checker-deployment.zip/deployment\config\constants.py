# Telegram bot constants
MAIN_MENU_TEXT = """🏠 *Головне меню*

Оберіть дію:"""

ADDRESS_MANAGEMENT_TEXT = """🏠 *Керування адресами*

Виберіть адресу для редагування або додайте нову:"""

NOTIFICATIONS_TEXT = """🔔 *Налаштування сповіщень*

Виберіть тип сповіщень:"""

# Emojis and symbols
EMOJI_LIGHT_ON = "🟢"
EMOJI_LIGHT_OFF = "🔴"
EMOJI_CLOCK = "🕐"
EMOJI_WARNING = "⚠️"
EMOJI_INFO = "ℹ️"
EMOJI_SUCCESS = "✅"
EMOJI_ERROR = "❌"
EMOJI_STAR = "⭐"

# Queue names mapping
QUEUE_NAMES = {
    "1": "Черга 1",
    "2": "Черга 2",
    "3": "Черга 3",
    "4": "Черга 4",
    "5": "Черга 5",
    "6": "Черга 6",
    "7": "Черга 7",
    "8": "Черга 8",
    "9": "Черга 9",
    "10": "Черга 10",
    "11": "Черга 11",
    "12": "Черга 12",
    "13": "Черга 13",
    "14": "Черга 14",
    "15": "Черга 15",
    "16": "Черга 16"
}

# Message templates
SCHEDULE_HEADER = "📅 *Графік відключень на {date}*\n\n🏠 *Адреса:* {address}\n🔢 *Черга:* {queue}\n\n"
NO_SCHEDULE_TEXT = "❌ На жаль, графік на цю дату відсутній"
LOADING_TEXT = "⏳ Завантаження..."

# Error messages
ERROR_DB_CONNECTION = "❌ Помилка підключення до бази даних"
ERROR_OCR_FAILED = "❌ Помилка розпізнавання зображення"
ERROR_INVALID_QUEUE = "❌ Неправильний номер черги"
ERROR_NO_ADDRESS = "❌ Адреса не знайдена"